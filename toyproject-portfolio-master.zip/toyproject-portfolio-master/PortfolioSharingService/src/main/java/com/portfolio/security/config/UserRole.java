package com.portfolio.security.config;

public enum UserRole {
	 ROLE_NOT_PERMITTED, ROLE_USER, ROLE_MANAGER, ROLE_ADMIN
}