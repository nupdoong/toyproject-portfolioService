package com.portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioSharingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioSharingServiceApplication.class, args);
	}

}
