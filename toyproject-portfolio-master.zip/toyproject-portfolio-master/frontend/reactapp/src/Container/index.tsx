export {default as MainPage} from './MainContainer';
export {default as SignUpPage} from './SignUpContainer';
export {default as SocialLoginingPage} from './SocialLoginingContainer';