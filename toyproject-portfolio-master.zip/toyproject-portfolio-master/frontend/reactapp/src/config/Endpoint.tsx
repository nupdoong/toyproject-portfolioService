export default {
    authServer : "http://localhost:8080"
};